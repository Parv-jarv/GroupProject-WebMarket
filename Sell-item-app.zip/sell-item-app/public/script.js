function previewImage(event) {
  const input = event.target;
  const preview = document.getElementById("preview");
  const file = input.files[0];

  if (file) {
    const reader = new FileReader();
    reader.onload = function(e) {
      preview.src = e.target.result;
      preview.style.display = 'block';
    };
    reader.readAsDataURL(file);
  }
}

document.getElementById('sellForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);

  const res = await fetch('/submit', {
    method: 'POST',
    body: formData
  });

  if (res.ok) {
    form.reset();
    document.getElementById("preview").style.display = 'none';
    loadListings();
  } else {
    alert('Failed to submit');
  }
});

async function loadListings() {
  const res = await fetch('/listings');
  const listings = await res.json();
  const container = document.getElementById('listingsContainer');
  container.innerHTML = '';
  listings.forEach(item => {
    const div = document.createElement('div');
    div.className = 'listing-box';
    div.innerHTML = `
      <img src="${item.image}" alt="Image of ${item.itemName}" />
      <strong>${item.itemName}</strong> (${item.quality})<br/>
      <strong>£${item.price}</strong><br/>
      ${item.description}
    `;
    container.appendChild(div);
  });
}

loadListings();
