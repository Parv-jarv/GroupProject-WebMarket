const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('listings.db');

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS listings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      itemName TEXT,
      quality TEXT,
      description TEXT,
      price REAL,
      image TEXT
    )
  `);
});

module.exports = db;
