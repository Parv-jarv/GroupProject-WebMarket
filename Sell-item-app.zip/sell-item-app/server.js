const express = require('express');
const multer = require('multer');
const path = require('path');
const bodyParser = require('body-parser');
const db = require('./db');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Ensure uploads directory exists
const uploadDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'public/uploads'),
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});
const upload = multer({ storage });

app.post('/submit', upload.single('itemImage'), (req, res) => {
  const { itemName, quality, description, price } = req.body;
  const image = req.file ? '/uploads/' + req.file.filename : '';

  db.run(
    `INSERT INTO listings (itemName, quality, description, price, image)
     VALUES (?, ?, ?, ?, ?)`,
    [itemName, quality, description, price, image],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, itemName, quality, description, price, image });
    }
  );
});

app.get('/listings', (req, res) => {
  db.all('SELECT * FROM listings ORDER BY id DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
