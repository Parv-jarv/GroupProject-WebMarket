import './profile.css'

document.addEventListener("DOMContentLoaded", () => {
    const token = localStorage.getItem("token");
    const username = localStorage.getItem("username");
    const email = localStorage.getItem("email");
    
    const userDash = document.getElementById("details");
    userDash.innerHTML = `
        <p class="details">Full Name: ${username}</p>
        <p class="details">Email: ${email}</p>
        <p class="details">Tel. Number: +00 0000001</p>
        <p class="details">Location: Brighton</p>
    `;

    document.getElementById("logo").addEventListener("click", () => {
        window.location.href = "http://localhost:5173/src/index.html";
    });

});