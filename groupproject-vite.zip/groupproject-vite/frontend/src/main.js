import './main.css';

document.addEventListener("DOMContentLoaded", fetchItems);

async function fetchItems() {
    try {
        const response = await fetch("http://localhost:5000/api/items");
        const items = await response.json();
        displayItems(items);
    } catch (error) {
        console.error("Error fetching items:", error);
    }
}

function displayItems(items) {
    const foodAndDrinkContainer = document.getElementById("food-and-drink-container");
    foodAndDrinkContainer.innerHTML = ""; 
    let foodAndDrinkCount = 0;
    const vehiclesContainer = document.getElementById("vehicles-container");
    vehiclesContainer.innerHTML = ""; 
    let vehiclesCount = 0;
    const animalsContainer = document.getElementById("animals-container");
    animalsContainer.innerHTML = ""; 
    let animalsCount = 0;

    const itemsScroller = document.getElementById("items-scroller");
    itemsScroller.innerHTML= "";

    items.forEach(item => {
        const itemElement = document.createElement("div");
        itemElement.classList.add("item-card");
        itemElement.dataset.category = item.category.toLowerCase(); 

        const itemElement_2 = document.createElement("div");
        itemElement_2.classList.add("item-card-price")
        itemElement_2.dataset.category = item.category.toLowerCase(); 

        itemElement.innerHTML = `
            <img src="${item.imageUrl}" alt="${item.title}" class="item-image">
        `;

        itemElement_2.innerHTML = `
            <img src="${item.imageUrl}" alt="${item.title}" class="item-image">
            <p class="item-description"><a href="#">${item.title}</a></p>
            <span class="item-price">${item.price}</span>
        `;
        
        if (item.category.toLowerCase() == "food and drink" && foodAndDrinkCount < 4) {
            foodAndDrinkContainer.appendChild(itemElement);
            foodAndDrinkCount++;
        }
        if (item.category.toLowerCase() == "vehicles" && vehiclesCount < 4) {
            vehiclesContainer.appendChild(itemElement);
            vehiclesCount++;
        }
        if (item.category.toLowerCase() == "animals" && animalsCount < 4) {
            animalsContainer.appendChild(itemElement);
            animalsCount++;
        }

        itemsScroller.append(itemElement_2);
    });
}

document.getElementById("search-term").addEventListener("input", function () {
    const searchQuery = this.value.toLowerCase();
    const items = document.querySelectorAll(".item-card");

    items.forEach(item => {
        const title = item.querySelector("h3").textContent.toLowerCase();
        item.style.display = title.includes(searchQuery) ? "block" : "none";
    });
});

function filterByCategory(category) {
    const items = document.querySelectorAll(".item-card");

    items.forEach(item => {
        const itemCategory = item.dataset.category;
        item.style.display = (category === "all" || itemCategory === category) ? "block" : "none";
    });
}

/*
document.getElementById("add-item-btn").addEventListener("click", function () {
    document.getElementById("add-item-form-container").classList.toggle("hidden");
});

document.getElementById("add-item-form").addEventListener("submit", async function (event) {
    event.preventDefault(); 

    const newItem = {
        title: document.getElementById("title").value,
        description: document.getElementById("description").value,
        price: document.getElementById("price").value,
        imageUrl: document.getElementById("imageUrl").value,
        location: document.getElementById("location").value,
        category: document.getElementById("category").value
    };

    try {
        const response = await fetch("http://localhost:5000/api/items", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(newItem)
        });

        if (response.ok) {
            alert("Item added successfully!");
            fetchItems(); 
            document.getElementById("add-item-form").reset();
            document.getElementById("add-item-form-container").classList.add("hidden");
        } else {
            alert("Error adding item.");
        }
    } catch (error) {
        console.error("Error:", error);
    }
});
*/

document.addEventListener("DOMContentLoaded", () => {
    const token = localStorage.getItem("token");
    const username = localStorage.getItem("username");

    const navButton = document.getElementById("nav-button");

    if (!navButton) return;

    if (token) {
        navButton.textContent = `Logout`;
        navButton.addEventListener("click", () => {
            localStorage.removeItem("token");
            localStorage.removeItem("username");
            console.log("Logged out");
            location.reload(); // optional
        });
    } else {
        navButton.textContent = `Login`;
        navButton.addEventListener("click", () => {
            window.location.href = "http://localhost:5173/src/login_page/login.html";
        });
    }

    document.getElementById("logo").addEventListener("click", () => {
        window.location.href = "http://localhost:5173/src/index.html";
    });
});

function clear(element) {
    document.getElementById(element).innerHTML = ``;
}


